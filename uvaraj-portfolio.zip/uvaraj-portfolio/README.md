# Uvaraj — Freelance Portfolio Website

A fast, responsive portfolio website for a freelance web developer and designer. Built with plain **HTML, CSS and JavaScript** — no build step, no dependencies.

## Features

- Home, About and Services pages (single-page navigation)
- Hero section with photo, availability badge and call-to-action buttons
- Selected work, skills, process, pricing packages and FAQ
- Contact form that opens the visitor's email app
- Mobile-first layout with automatic light and dark mode
- Keyboard-friendly and respects reduced-motion settings

## Project structure

```
uvaraj-portfolio/
├── index.html      # page structure and content
├── style.css       # all styling
├── script.js       # page navigation, menu and contact form
├── assets/
│   └── uvaraj.jpg  # profile photo
└── README.md
```

## Run locally

Open `index.html` in any browser. That's it.

Or start a local server (optional):

```bash
npx serve .
```

## Customize before publishing

| What | Where |
| --- | --- |
| Email address | `index.html` (contact section) and `script.js` (`mailto:` line) |
| Phone number and location | `index.html` (contact section) |
| Projects, prices, skills | `index.html` |
| About text and education | `index.html` (About page) |
| Colors and fonts | `style.css` (variables at the top, under `:root`) |
| Photo | Replace `assets/uvaraj.jpg` (keep a 3:4 portrait for the best fit) |

Search for `your.email@example.com` and `+91 00000 00000` to find every placeholder contact detail.

## Upload to GitHub

### Option A — Using the GitHub website

1. Sign in at [github.com](https://github.com) and click **New repository**.
2. Name it `uvaraj-portfolio`, keep it **Public**, and click **Create repository**.
3. Click **uploading an existing file**, drag in all files and the `assets` folder, then click **Commit changes**.

### Option B — Using Git

```bash
cd uvaraj-portfolio
git init
git add .
git commit -m "Initial commit: portfolio website"
git branch -M main
git remote add origin https://github.com/<your-username>/uvaraj-portfolio.git
git push -u origin main
```

Replace `<your-username>` with your GitHub username.

## Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) and sign up with your GitHub account.
2. Click **Add New… → Project**.
3. Select the `uvaraj-portfolio` repository and click **Import**.
4. Leave the settings as they are:
   - **Framework Preset:** Other
   - **Build Command:** empty
   - **Output Directory:** empty
5. Click **Deploy**. Your site goes live at `https://uvaraj-portfolio.vercel.app` (or a similar address) in about a minute.

Every time you push a change to GitHub, Vercel redeploys automatically.

### Custom domain (optional)

In your Vercel project, open **Settings → Domains**, add your domain (for example `uvaraj.com`) and follow the DNS instructions shown.

## Make the contact form send messages directly (optional)

The form currently opens the visitor's email app. To receive messages without that step, use a free form service such as [Formspree](https://formspree.io):

1. Create a form on Formspree and copy its endpoint URL.
2. In `index.html`, change the form tag to `<form action="YOUR_ENDPOINT_URL" method="POST">`.
3. Remove the submit handler for `#cform` in `script.js`.

## Tech

- HTML5, CSS3, vanilla JavaScript
- Fonts: [Fraunces](https://fonts.google.com/specimen/Fraunces) and [Manrope](https://fonts.google.com/specimen/Manrope) via Google Fonts

## License

© 2026 Uvaraj. All rights reserved.
